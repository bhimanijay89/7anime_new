/*!
 * YouTube Ambilight Engine — Reusable Web Entrypoint
 * MIT License — Copyright (c) 2017 Wessel Kroos
 */
export { createWebAmbilight } from './ambilight-controller';
export {
  default as WebAmbilightSettings,
  fadeDurationMsToFrameFading,
} from './web-settings';
export {
  default as AmbientlightCore,
  getRenderedVideoClientRect,
} from '../scripts/libs/ambientlight-core';
export { default as ProjectorWebGL } from '../scripts/libs/projector-webgl';
export { default as Projector2d } from '../scripts/libs/projector-2d';
export { default as ProjectorShadow } from '../scripts/libs/projector-shadow';
export { WebGLOffscreenCanvas } from '../scripts/libs/canvas-webgl';
export { default as BarDetection } from '../scripts/libs/bar-detection';
export {
  VIEW_DISABLED,
  VIEW_DETACHED,
  VIEW_SMALL,
  VIEW_THEATER,
  VIEW_FULLSCREEN,
  supportsWebGL,
} from '../scripts/libs/generic';
