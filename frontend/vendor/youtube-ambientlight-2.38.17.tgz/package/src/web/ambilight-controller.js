/*!
 * Web Controller for YouTube Ambilight Engine
 * Copyright (c) 2017 Wessel Kroos (MIT License)
 */
import AmbientlightCore from '../scripts/libs/ambientlight-core';
import {
  VIEW_FULLSCREEN,
  VIEW_SMALL,
  VIEW_THEATER,
} from '../scripts/libs/generic';
import WebAmbilightSettings from './web-settings';

function resolveViewConstant(view) {
  if (view === 'fullscreen' || view === VIEW_FULLSCREEN) return VIEW_FULLSCREEN;
  if (view === 'theater' || view === VIEW_THEATER) return VIEW_THEATER;
  return VIEW_SMALL;
}

export function createWebAmbilight(options) {
  const {
    video,
    stage,
    videoContainer,
    scrollContainer,
    getFullscreenElement,
    getView,
    settings: initialSettings = {},
    onFrameRendered,
    onVisibilityChange,
    onWarning,
    onReady,
  } = options || {};

  if (!video || !stage) {
    throw new Error('createWebAmbilight requires both `video` and `stage` DOM elements.');
  }

  let currentView = resolveViewConstant(
    typeof getView === 'function' ? getView() : options.view
  );
  let destroyed = false;
  let engine = null;

  const webSettings = new WebAmbilightSettings(initialSettings, { onWarning });

  const initPromise = new AmbientlightCore(video, {
    webMode: true,
    useViewportCrop: true,
    globalDocumentAttrs: false,
    stageElem: stage,
    videoPlayerElem: stage,
    videoContainerElem: videoContainer || video.parentElement || stage,
    scrollContainer:
      scrollContainer || stage.closest?.('.content.browse-scroll') || undefined,
    getFullscreenElem:
      getFullscreenElement ||
      (() => document.fullscreenElement || stage),
    getView: () => {
      if (document.fullscreenElement) return VIEW_FULLSCREEN;
      if (typeof getView === 'function') {
        return resolveViewConstant(getView());
      }
      return currentView;
    },
    settings: webSettings,
    onFrameRendered,
    onVisibilityChange,
  })
    .then((instance) => {
      if (destroyed) {
        instance?.destroy?.();
        return null;
      }
      engine = instance;
      onReady?.(instance);
      return instance;
    })
    .catch((err) => {
      if (!destroyed) {
        onWarning?.(err?.message || 'Failed to start Ambilight engine');
      }
      return null;
    });

  return {
    ready: initPromise,
    async updateSettings(nextSettings) {
      if (destroyed) return;
      await initPromise;
      if (destroyed) return;
      await webSettings.update(nextSettings);
    },
    async setView(view) {
      currentView = resolveViewConstant(view);
      if (destroyed) return;
      await initPromise;
      if (destroyed || !engine) return;
      engine.sizesChanged = true;
      await engine.updateView(true);
      await engine.optionalFrame(true);
    },
    async resize() {
      if (destroyed) return;
      await initPromise;
      if (destroyed || !engine) return;
      engine.sizesChanged = true;
      await engine.optionalFrame(true);
    },
    getEngine() {
      return engine;
    },
    getSettings() {
      return webSettings;
    },
    destroy() {
      if (destroyed) return;
      destroyed = true;
      webSettings.destroy();
      if (engine) {
        engine.destroy();
        engine = null;
      }
    },
  };
}
