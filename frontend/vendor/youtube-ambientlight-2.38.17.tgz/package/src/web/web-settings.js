/*!
 * Web Settings Adapter for YouTube Ambilight Engine
 * Copyright (c) 2017 Wessel Kroos (MIT License)
 */
import SettingsConfig, {
  prepareSettingsConfigOnce,
} from '../scripts/libs/settings-config';
import { setWarningHandler, supportsWebGL } from '../scripts/libs/generic';

const DEFAULT_EDGE_FOR_BLUR = (blur) =>
  blur <= 5 ? 2 : blur >= 42.5 ? 17 : Math.round((blur / 2.5) * 10) / 10;

export function fadeDurationMsToFrameFading(fadeDurationMs) {
  const ms = Number(fadeDurationMs);
  if (!Number.isFinite(ms) || ms <= 0) return 0;
  // Reference engine maps frameFading^2 frames at 30 fps (max 21.2 -> 15s)
  return Math.min(21.2, Math.sqrt((ms / 1000) * 30));
}

export default class WebAmbilightSettings {
  ambientlight = null;
  fadeDurationMs = 497;
  enabledViews = { small: true, theater: true, fullscreen: true };
  webGLCrashDate = undefined;
  webGLCrashVersion = undefined;
  #pendingFadeRecompile = null;
  #onWarning = null;
  #advancedEdgePinned = false;

  constructor(initial = {}, callbacks = {}) {
    prepareSettingsConfigOnce();

    for (const entry of SettingsConfig) {
      if (entry.type === 'section' || !entry.name) continue;
      this[entry.name] = entry.default;
    }

    // Sensible web defaults tuned off the reference engine
    this.webGL = initial.webGL ?? supportsWebGL();
    this.enabled = initial.enabled ?? true;
    this.prioritizePageLoadSpeed = false;
    this.layoutPerformanceImprovements = false;
    this.enableInEmbed = true;
    this.fixedPosition = false;
    this.surroundingContentShadowSize = 0;
    this.surroundingContentShadowOpacity = 0;
    this.headerShadowSize = 0;
    this.headerShadowOpacity = 0;

    this.#onWarning = callbacks.onWarning ?? null;
    if (this.#onWarning) {
      setWarningHandler((text, ...rest) => this.#onWarning(text, ...rest));
    }

    this.applyInitialValues(initial);
  }

  attachAmbientlight(ambientlight) {
    this.ambientlight = ambientlight;
  }

  applyInitialValues(values = {}) {
    if (typeof values.edge === 'number' && Number.isFinite(values.edge)) {
      this.#advancedEdgePinned = true;
      this.edge = Math.min(60, Math.max(0.3, values.edge));
    }

    const blurVal =
      typeof values.blur === 'number'
        ? values.blur
        : typeof values.blur2 === 'number'
        ? values.blur2
        : 15.5;
    this.blur2 = Math.min(100, Math.max(0, blurVal));
    if (!this.#advancedEdgePinned) {
      this.edge = DEFAULT_EDGE_FOR_BLUR(this.blur2);
    }

    const maxSpread = this.webGL ? 400 : 200;
    const spreadVal = typeof values.spread === 'number' ? values.spread : 155;
    this.spread = Math.min(maxSpread, Math.max(0, spreadVal));

    const fadeMs =
      typeof values.fadeDurationMs === 'number'
        ? values.fadeDurationMs
        : typeof values.fadeDuration === 'number'
        ? values.fadeDuration
        : 497;
    this.fadeDurationMs = Math.min(5000, Math.max(0, fadeMs));
    this.frameFading = fadeDurationMsToFrameFading(this.fadeDurationMs);
    this.framerateLimit = this.frameFading > 0 ? 30 : 60;

    if (values.enabledLayouts || values.enabledViews) {
      const views = values.enabledLayouts || values.enabledViews;
      this.enabledViews = {
        small: Boolean(views.small ?? true),
        theater: Boolean(views.theater ?? true),
        fullscreen: Boolean(views.fullscreen ?? true),
      };
    }

    for (const key of [
      'vibrance',
      'saturation',
      'brightness',
      'contrast',
      'spreadFadeStart',
      'spreadFadeCurve',
      'flickerReduction',
      'resolution',
      'framerateLimit',
      'debandingStrength',
      'detectHorizontalBarSizeEnabled',
      'detectVerticalBarSizeEnabled',
    ]) {
      if (typeof values[key] === 'number' && Number.isFinite(values[key])) {
        this[key] = values[key];
      } else if (typeof values[key] === 'boolean') {
        this[key] = values[key];
      }
    }
  }

  set = (name, value) => {
    this[name] = value;
  };

  setWarning = (text, ...rest) => {
    if (this.#onWarning) {
      this.#onWarning(text || '', ...rest);
    } else if (text) {
      console.warn('[WebAmbilight]', text);
    }
  };

  saveStorageEntry() {}

  updateVisibility() {}

  onLoaded() {}

  onCloseMenu = () => {};

  displayBezelForSetting() {}

  async updateHdr() {
    await this.ambientlight?.updateHdr?.();
  }

  updateAverageVideoFramesDifferenceInfo() {}

  updateWebGLCrashDescription() {}

  getKeys = () => ({});

  handleWebGLCrash = () => {
    this.webGL = false;
    this.webGLCrashDate = Date.now();
    if (this.spread > 200) {
      this.spread = 200;
    }
  };

  async update(next = {}) {
    const al = this.ambientlight;
    const prevEnabled = this.enabled;
    const prevBlur = this.blur2;
    const prevSpread = this.spread;
    const prevEdge = this.edge;
    const prevFadeFrames = Math.round(Math.pow(this.frameFading || 0, 2));
    const prevFadeMs = this.fadeDurationMs;
    const prevViews = { ...this.enabledViews };
    const prevVibrance = this.vibrance;
    const prevVisualFilter =
      this.brightness !== next.brightness ||
      this.contrast !== next.contrast ||
      this.saturation !== next.saturation;

    if (typeof next.enabled === 'boolean') {
      this.enabled = next.enabled;
    }
    if (typeof next.blur === 'number' && Number.isFinite(next.blur)) {
      this.blur2 = Math.min(100, Math.max(0, next.blur));
      if (!this.#advancedEdgePinned) {
        this.edge = DEFAULT_EDGE_FOR_BLUR(this.blur2);
      }
    }
    if (typeof next.edge === 'number' && Number.isFinite(next.edge)) {
      this.#advancedEdgePinned = true;
      this.edge = Math.min(60, Math.max(0.3, next.edge));
    }
    if (typeof next.spread === 'number' && Number.isFinite(next.spread)) {
      const maxSpread = this.webGL ? 400 : 200;
      this.spread = Math.min(maxSpread, Math.max(0, next.spread));
    }
    const nextFade =
      typeof next.fadeDurationMs === 'number'
        ? next.fadeDurationMs
        : typeof next.fadeDuration === 'number'
        ? next.fadeDuration
        : undefined;
    if (typeof nextFade === 'number' && Number.isFinite(nextFade)) {
      this.fadeDurationMs = Math.min(5000, Math.max(0, nextFade));
      this.frameFading = fadeDurationMsToFrameFading(this.fadeDurationMs);
      this.framerateLimit =
        typeof next.framerateLimit === 'number'
          ? next.framerateLimit
          : this.frameFading > 0
          ? 30
          : 60;
    }
    if (next.enabledLayouts || next.enabledViews) {
      const views = next.enabledLayouts || next.enabledViews;
      this.enabledViews = {
        small: Boolean(views.small ?? this.enabledViews.small),
        theater: Boolean(views.theater ?? this.enabledViews.theater),
        fullscreen: Boolean(views.fullscreen ?? this.enabledViews.fullscreen),
      };
    }
    for (const key of [
      'vibrance',
      'saturation',
      'brightness',
      'contrast',
      'spreadFadeStart',
      'spreadFadeCurve',
      'resolution',
    ]) {
      if (typeof next[key] === 'number' && Number.isFinite(next[key])) {
        this[key] = next[key];
      }
    }

    if (!al || al.destroyed) return;

    const viewsChanged =
      prevViews.small !== this.enabledViews.small ||
      prevViews.theater !== this.enabledViews.theater ||
      prevViews.fullscreen !== this.enabledViews.fullscreen;

    if (
      prevSpread !== this.spread ||
      prevEdge !== this.edge ||
      prevVibrance !== this.vibrance
    ) {
      al.canvassesInvalidated = true;
    }

    if (
      prevBlur !== this.blur2 ||
      prevSpread !== this.spread ||
      prevEdge !== this.edge ||
      prevVibrance !== this.vibrance ||
      prevVisualFilter ||
      viewsChanged
    ) {
      al.sizesChanged = true;
    }

    if (prevEnabled !== this.enabled) {
      if (this.enabled) {
        await al.enable(true);
      } else {
        await al.disable();
      }
      return;
    }

    if (this.fadeDurationMs !== prevFadeMs || prevVisualFilter) {
      al.updateStyles();
    }

    const nextFadeFrames = Math.round(Math.pow(this.frameFading || 0, 2));
    if (nextFadeFrames !== prevFadeFrames && this.webGL && al.projector?.initCtx) {
      if (this.#pendingFadeRecompile) {
        clearTimeout(this.#pendingFadeRecompile);
      }
      this.#pendingFadeRecompile = globalThis.setTimeout(async () => {
        this.#pendingFadeRecompile = null;
        if (!al || al.destroyed) return;
        try {
          al.canvassesInvalidated = true;
          al.sizesChanged = true;
          await al.projector.initCtx();
          al.buffersCleared = true;
          await al.optionalFrame(true);
        } catch (ex) {
          this.setWarning(`Failed to update fade transition: ${ex?.message || ex}`);
        }
      }, 65);
    }

    if (prevVibrance !== this.vibrance && this.webGL && al.projector?.updateVibrance) {
      await al.projector.updateVibrance();
    }

    if (
      prevBlur !== this.blur2 ||
      prevSpread !== this.spread ||
      prevEdge !== this.edge ||
      prevVibrance !== this.vibrance ||
      prevVisualFilter ||
      viewsChanged
    ) {
      await al.optionalFrame(true);
    }
  }

  destroy() {
    if (this.#pendingFadeRecompile) {
      clearTimeout(this.#pendingFadeRecompile);
      this.#pendingFadeRecompile = null;
    }
    this.ambientlight = null;
  }
}
