export type AmbilightViewMode = 'small' | 'theater' | 'fullscreen';

export interface WebAmbilightEnabledViews {
  small: boolean;
  theater: boolean;
  fullscreen: boolean;
}

export interface WebAmbilightSettingsInput {
  enabled?: boolean;
  blur?: number;
  blur2?: number;
  edge?: number;
  spread?: number;
  fadeDurationMs?: number;
  fadeDuration?: number;
  enabledLayouts?: Partial<WebAmbilightEnabledViews>;
  enabledViews?: Partial<WebAmbilightEnabledViews>;
  vibrance?: number;
  saturation?: number;
  brightness?: number;
  contrast?: number;
  spreadFadeStart?: number;
  spreadFadeCurve?: number;
  flickerReduction?: number;
  resolution?: number;
  framerateLimit?: number;
  debandingStrength?: number;
  webGL?: boolean;
}

export interface WebAmbilightFrameInfo {
  frameCount: number;
  width: number;
  height: number;
  renderer: string;
  webGLVersion?: number;
}

export interface CreateWebAmbilightOptions {
  video: HTMLVideoElement;
  stage: HTMLElement;
  videoContainer?: HTMLElement | null;
  scrollContainer?: HTMLElement | null;
  getFullscreenElement?: () => Element | null | undefined;
  getView?: () => AmbilightViewMode;
  view?: AmbilightViewMode;
  settings?: WebAmbilightSettingsInput;
  onFrameRendered?: (info: WebAmbilightFrameInfo) => void;
  onVisibilityChange?: (visible: boolean) => void;
  onWarning?: (message: string) => void;
  onReady?: (engine: unknown) => void;
}

export interface WebAmbilightController {
  ready: Promise<unknown>;
  updateSettings(next: WebAmbilightSettingsInput): Promise<void>;
  setView(view: AmbilightViewMode): Promise<void>;
  resize(): Promise<void>;
  getEngine(): unknown;
  getSettings(): Record<string, unknown>;
  destroy(): void;
}

export declare function fadeDurationMsToFrameFading(fadeDurationMs: number): number;
export declare function createWebAmbilight(
  options: CreateWebAmbilightOptions
): WebAmbilightController;
export declare function supportsWebGL(): boolean;
export declare const VIEW_DISABLED: string;
export declare const VIEW_DETACHED: string;
export declare const VIEW_SMALL: string;
export declare const VIEW_THEATER: string;
export declare const VIEW_FULLSCREEN: string;
